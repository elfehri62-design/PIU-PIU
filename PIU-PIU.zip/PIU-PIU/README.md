# PIU-PIU

Première maquette HTML de l'application sociale PIU-PIU.

## Tester
Ouvre `index.html` dans un navigateur web.

Cette version est une maquette visuelle : les comptes, messages, photos et lives réels nécessiteront un backend et des services supplémentaires.
